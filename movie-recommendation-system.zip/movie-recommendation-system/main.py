"""
main.py
-------
Runs the ENTIRE pipeline end-to-end, in the same order a student would
follow while building any AI/ML project:

    1. LOAD data
    2. EXPLORE data (basic stats)
    3. SPLIT into train / test
    4. DESIGN + TRAIN the algorithm (fit)
    5. TEST / VALIDATE (predict on unseen data)
    6. MEASURE performance (RMSE, MAE, Precision@K, Recall@K)
    7. USE the trained model to generate real recommendations

Run with:  python main.py
"""

import pandas as pd

from src.data_loader import load_raw_data, basic_stats, build_user_item_matrix
from src.train_test_split import train_test_split_per_user
from src.collaborative_filtering import UserBasedCF
from src.evaluate import print_evaluation_report

RATINGS_PATH = "data/ratings.csv"
MOVIES_PATH = "data/movies.csv"


def main():
    # ---------- 1. LOAD ----------
    print("\n[1/6] Loading data...")
    ratings_df, movies_df = load_raw_data(RATINGS_PATH, MOVIES_PATH)

    # ---------- 2. EXPLORE ----------
    print("\n[2/6] Exploring data...")
    basic_stats(ratings_df, movies_df)

    # ---------- 3. SPLIT ----------
    print("\n[3/6] Splitting into train / test sets...")
    train_df, test_df = train_test_split_per_user(ratings_df, test_fraction=0.2)
    print(f"Train ratings: {len(train_df)} | Test ratings: {len(test_df)}")

    # ---------- 4. DESIGN + TRAIN ----------
    print("\n[4/6] Training the User-Based Collaborative Filtering model...")
    model = UserBasedCF(k_neighbors=10)
    model.fit(train_df)
    print(f"Trained on matrix of shape {model.user_item_matrix.shape} "
          f"(users x movies)")

    # ---------- 5. TEST / VALIDATE + 6. MEASURE ----------
    print("\n[5/6] Evaluating on the held-out TEST set...")
    print_evaluation_report(model, train_df, test_df, movies_df, k=5)

    # ---------- 7. USE THE MODEL ----------
    print("\n[6/6] Sample recommendations:")
    sample_user = train_df["user_id"].iloc[0]
    recs = model.recommend(sample_user, movies_df, top_n=5)
    print(f"\nTop 5 movie recommendations for User {sample_user}:")
    print(recs.to_string(index=False))


if __name__ == "__main__":
    main()
