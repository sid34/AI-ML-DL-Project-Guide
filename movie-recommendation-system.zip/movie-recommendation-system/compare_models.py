"""
compare_models.py
------------------
Compares the BASELINE (popularity) model against the MAIN algorithm
(user-based collaborative filtering), exactly as recommended in
Phase 4, Step 14 of the project guide: always report a comparison
table, never just one model's score in isolation.

Run with:  python compare_models.py
"""

import numpy as np
import pandas as pd

from src.data_loader import load_raw_data
from src.train_test_split import train_test_split_per_user
from src.collaborative_filtering import UserBasedCF
from src.baseline import PopularityRecommender
from src.evaluate import rmse_mae, print_evaluation_report


def baseline_rmse_mae(model, test_df):
    errors = []
    for _, row in test_df.iterrows():
        pred = model.predict(row["user_id"], row["movie_id"])
        errors.append(pred - row["rating"])
    errors = np.array(errors)
    return np.sqrt(np.mean(errors ** 2)), np.mean(np.abs(errors))


def main():
    ratings_df, movies_df = load_raw_data("data/ratings.csv", "data/movies.csv")
    train_df, test_df = train_test_split_per_user(ratings_df, test_fraction=0.2)

    print("Training baseline (Popularity) model...")
    baseline = PopularityRecommender(min_ratings=3).fit(train_df)
    b_rmse, b_mae = baseline_rmse_mae(baseline, test_df)

    print("Training main model (User-Based Collaborative Filtering)...")
    cf_model = UserBasedCF(k_neighbors=10).fit(train_df)
    cf_report = print_evaluation_report(cf_model, train_df, test_df, movies_df, k=5)

    print("\n===== MODEL COMPARISON TABLE =====")
    print(f"{'Model':35s}{'RMSE':>8s}{'MAE':>8s}")
    print(f"{'Baseline (Popularity)':35s}{b_rmse:8.3f}{b_mae:8.3f}")
    print(f"{'Collaborative Filtering (main)':35s}{cf_report['rmse']:8.3f}{cf_report['mae']:8.3f}")
    print("===================================")
    print("\nLower RMSE/MAE = better. The main model should score lower than\n"
          "the baseline if it is genuinely learning individual user taste.")


if __name__ == "__main__":
    main()
